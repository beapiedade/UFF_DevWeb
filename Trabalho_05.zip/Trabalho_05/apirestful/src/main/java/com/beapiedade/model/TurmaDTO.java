package com.beapiedade.model;

import lombok.Data;

@Data
public class TurmaDTO {
    private String id;
    private int ano;
    private int periodo;
    private Long professorId;
    private Long disciplinaId;
}